-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2018 at 07:20 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.1.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE `tbl_book` (
  `bookid` int(11) NOT NULL,
  `bookname` varchar(100) NOT NULL,
  `dep` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_book`
--

INSERT INTO `tbl_book` (`bookid`, `bookname`, `dep`, `author`) VALUES
(1, 'Introduction of computer Science', '5', 'TeacherTwo'),
(2, 'Analog Electronics', '7', 'Robiul Alam'),
(3, 'Software Engineering', '1', 'TeacherOne'),
(4, 'Class six book one', '7', 'Class six teacher'),
(5, 'Class six book Two', '7', 'Class six teacher'),
(6, 'Class six book Three', '7', 'Class six teacher'),
(7, 'Class Seven book one', '6', 'Class Seven Teacher'),
(8, 'Class Seven book Two', '6', 'Class Seven Teacher'),
(9, 'Class Seven book Three', '6', 'Class Seven Teacher'),
(10, 'Class Eight book one', '5', 'Class Eight Teacher'),
(11, 'Class Eight book Two', '5', 'Class Eight Teacher'),
(12, 'Class Eight book Three', '5', 'Class Eight Teacher'),
(13, 'Class Nine book one', '1', 'Class Nine Teacher'),
(14, 'Class Nine book Two', '1', 'Class Nine Teacher'),
(15, 'Class Nine book Three', '1', 'Class Nine Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dep`
--

CREATE TABLE `tbl_dep` (
  `depid` int(11) NOT NULL,
  `depname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_dep`
--

INSERT INTO `tbl_dep` (`depid`, `depname`) VALUES
(1, 'Class Nine'),
(5, 'Class Eight'),
(6, 'Class Seven'),
(7, 'Class Six');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_issue`
--

CREATE TABLE `tbl_issue` (
  `id` int(11) NOT NULL,
  `studentname` varchar(100) NOT NULL,
  `reg` int(11) NOT NULL,
  `dep` int(11) NOT NULL,
  `book` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `return_book` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_issue`
--

INSERT INTO `tbl_issue` (`id`, `studentname`, `reg`, `dep`, `book`, `date`, `return_book`) VALUES
(2, 'Saiful Islam', 3654, 1, 13, '2018-09-10 08:16:30', '12/09/2018'),
(3, 'Kolpo Azad', 3548, 5, 11, '2018-09-10 08:17:10', '15/09/2018'),
(4, 'Nazmus Sakib', 3549, 1, 15, '2018-09-10 13:44:30', '19/09/2018');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `sid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dep` varchar(100) NOT NULL,
  `roll` int(5) NOT NULL,
  `reg` int(5) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`sid`, `name`, `dep`, `roll`, `reg`, `phone`, `image`) VALUES
(1, 'Robiul Alam', '1', 1, 1994, '01814785328', 'uploads/avatar211.png'),
(2, 'Sojib Hossain', '1', 2, 1234, '01814785325', 'uploads/avatar210.png'),
(3, 'Mehedi Hasan', '7', 1, 3214, '01814785378', 'uploads/avatar29.png'),
(4, 'Arif Hossain', '6', 9, 1048, '01814785345', 'uploads/avatar28.png'),
(5, 'Mosaddeq Hossain', '6', 4, 1254, '01814785348', 'uploads/avatar212.png'),
(6, 'Nifaz Ahmed', '7', 10, 2248, '01814785376', 'uploads/avatar27.png'),
(7, 'Nayeem Islam', '7', 12, 1845, '01814785347', 'uploads/avatar26.png'),
(8, 'Kazi Sumon', '7', 7, 3012, '01814785334', 'uploads/avatar25.png'),
(9, 'Kazi Faisal ', '1', 8, 1245, '01814785385', 'uploads/avatar24.png'),
(10, 'Pohel Shawdagor', '6', 9, 2531, '01814785335', 'uploads/avatar23.png'),
(11, 'Kolpo Azad', '5', 13, 3548, '01814785352', 'uploads/avatar22.png'),
(12, 'Saiful Islam', '1', 16, 3654, '01814785487', 'uploads/avatar21.png'),
(13, 'Nazmus Sakib', '1', 15, 3549, '01701247900', 'uploads/avatar2.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `pass_hints` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `user`, `pass`, `pass_hints`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `tbl_dep`
--
ALTER TABLE `tbl_dep`
  ADD PRIMARY KEY (`depid`);

--
-- Indexes for table `tbl_issue`
--
ALTER TABLE `tbl_issue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_book`
--
ALTER TABLE `tbl_book`
  MODIFY `bookid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_dep`
--
ALTER TABLE `tbl_dep`
  MODIFY `depid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_issue`
--
ALTER TABLE `tbl_issue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
