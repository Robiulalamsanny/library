
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Update Book</h4> 
                           <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                    <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>book/updateBookForm" method="post">
                                        <input type="hidden" class="form-control" name="bookid" value="<?php echo $bookById->bookid; ?>" >

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Book Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="bookname" value="<?php echo $bookById->bookname; ?>" >
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="dep">
                                                <option>Select One</option>
                                                <?php 
                                                    foreach ($departmentData as $ddata) { ?>
                                                        <?php if ($bookById->dep == $ddata->depid) { ?>
                                                       <option value="<?php echo $ddata->depid?>" selected="selected"> <?php echo $ddata->depname?></option>  
                                                        <?php   } ?>
                                                <option value="<?php echo $ddata->depid?>"> <?php echo $ddata->depname?>  </option>
                                                <?php } ?>
                                            </select>
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Author</label>
                                            </div>

                                            <div class="col-md-8">
                                            <input type="text"  class="form-control" name="author" value="<?php echo $bookById->author; ?>" >
                                            </div>
                                        </div>

                                       

                                        

                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div>

                                       
                                    </form>
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








