
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Add Student</h4> 
                           <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                   <!--  <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>student/addStudentForm" method="post"> -->
                                    <form action="<?php echo base_url(); ?>student/addStudentForm" class=form-horizontal enctype="multipart/form-data" method="post" accept-charset="utf-8">
                                    

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Student Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="name" required >
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="dep">
                                                <option>Select One</option>
                                                <?php 
                                                    foreach ($getDepartment as $ddata) {
                                                    
                                                ?>

                                                <option value="<?php echo $ddata->depid?>"><?php echo $ddata->depname?></option>
                                                <?php } ?>
                                            </select>
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Roll No</label>
                                            </div>

                                            <div class="col-md-8">
                                            <input type="text"  class="form-control" name="roll" required>
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Reg. No</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text"  class="form-control" name="reg" required>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Phone No</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text"  class="form-control" name="phone" required>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Image</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="file"  class="form-control" name="image" >
                                            </div>
                                        </div>

                                        

                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div>

                                     
                                    </form>
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








