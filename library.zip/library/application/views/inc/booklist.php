
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Student List</h4>
                             <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Book Name</th>
                                        <th>Department Name</th>
                                        <th>Author</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php
                                $i = 0;
                                foreach ($allBook as  $bdata) {
                                $i++;
                               
                            ?>

                                    <tr class="odd gradeX">
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $bdata->bookname; ?></td>
                                        <td>
                                            <?php 
                                            $sdepid = $bdata->dep;
                                            $getdep = $this->dep_model->getDepartment($sdepid); 
                                            if (isset($getdep)) {
                                                echo $getdep->depname;
                                            }
                                            ?>
                                                
                                        </td>
                                        <td><?php echo $bdata->author; ?></td>
                                        <td>
                                            <a href="<?php echo base_url(); ?>book/editbook/<?php echo $bdata->bookid; ?>"><i class="fa fa-pencil"></i></a>
                                            <a onclick="return confirm('Are you sure to delete')" href="<?php echo base_url(); ?>book/delbook/<?php echo $bdata->bookid; ?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                   
                                    <?php } ?>
                                    
                                </tbody>
                            </table>
                          
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
