
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Student List</h4>
                             <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Department</th>
                                        <th>Roll</th>
                                        <th>Reg</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php
                                $i = 0;
                                foreach ($getstudent as  $sdata) {
                                $i++;
                               
                            ?>

                                    <tr class="odd gradeX">
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $sdata->name; ?></td>
                                        <td class="center">
                                            <img src="<?php echo base_url().$sdata->image; ?>" width="100px" height="100px" alt="">
                                        </td>
                                        <td>
                                            <?php 
                                            $sdepid = $sdata->dep;
                                            $getdep = $this->dep_model->getDepartment($sdepid); 
                                            if (isset($getdep)) {
                                                echo $getdep->depname;
                                            }
                                            ?>
                                                
                                        </td>
                                        <td><?php echo $sdata->roll; ?></td>
                                        <td><?php echo $sdata->reg; ?></td>
                                        <td><?php echo $sdata->phone; ?></td>
                                        <td>
                                            <a href="<?php echo base_url(); ?>student/editstudent/<?php echo $sdata->sid; ?>"><i class="fa fa-pencil"></i></a>
                                            <a onclick="return confirm('Are you sure to delete')" href="<?php echo base_url(); ?>student/delstudent/<?php echo $sdata->sid; ?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                   
                                    <?php } ?>
                                    
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
