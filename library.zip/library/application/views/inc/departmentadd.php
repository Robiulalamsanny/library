
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Add Department</h4> 
                         <?php
                        
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?> 
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                    <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>department/addDepartmentForm" method="post">

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="depname">
                                            </div>
                                        </div>

                                      

                                        

                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div>

                                       
                                    </form>
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








