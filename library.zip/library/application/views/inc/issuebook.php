<script>
    $(document).ready(function(){ 
        $("#department").change(function(){
            var dep =  $("#department").val();
            $.ajax({
                type:"POST",
                url:"<?php echo base_url(); ?>manage/getBookByDepId/"+dep,
                success:function(data){
                    $("#book").html(data);
                }
            });
        });

    });
</script>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Issue Book</h4> 
                           <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                    <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>manage/addIssueForm" method="post">

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Student Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="studentname">
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Reg</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="reg">
                                            </div>
                                        </div>


                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="dep" id="department">
                                                <option>Select One</option>
                                                <?php 
                                                    foreach ($getDepartment as $ddata) {
                                                    
                                                ?>

                                                <option value="<?php echo $ddata->depid?>"><?php echo $ddata->depname?></option>
                                                <?php } ?>
                                            </select>
                                            </div>
                                        </div>

                                         

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Book Name</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="book" id="book">
                                              
                                      
                                            </select>
                                            </div>
                                        </div>



                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Return Date <br>(Hints: 12/09/2018)</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="return_book">
                                            </div>
                                        </div>



                                    

                                        

                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div>

                                       
                                    </form>
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








