
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4> Student Details</h4> 
                         
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                 <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>" method="post">

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Student Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" readonly class="form-control" value="<?php echo $studentdata->name; ?>" name="name">
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department</label>
                                            </div>
                                            <div class="col-md-8">
                                                <input type="text" readonly class="form-control" value=" <?php $sdepid = $studentdata->dep; $getdep = $this->dep_model->getDepartment($sdepid); if (isset($getdep)) { echo $getdep->depname; } ?>" name="name">
                                            </div>
                                        </div>
                                       

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Roll No</label>
                                            </div>

                                            <div class="col-md-8">
                                            <input type="text" readonly  class="form-control" name="roll" value="<?php echo $studentdata->roll; ?>"  >
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Reg. No</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text" readonly  class="form-control" name="reg" value="<?php echo $studentdata->reg; ?>"  >
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Phone Number</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text" readonly  class="form-control" name="phone" value="<?php echo $studentdata->phone; ?>"  >
                                            </div>
                                        </div>

                                        
<!-- 
                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div> -->

                             </form>
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








