
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Department List</h4>
                             <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Student Name</th>
                                        <th>Department</th>
                                        <th>Reg</th>
                                        <th>Book Name</th>
                                        <th>Issue Date</th>
                                        <th>Return Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php
                                $i = 0;
                                foreach ($allIssuebook as  $idata) {
                                $i++;
                               
                            ?>

                                    <tr class="odd gradeX">
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $idata->studentname; ?></td>
                                         <td>
                                            <?php 
                                            $sdepid = $idata->dep;
                                            $getdep = $this->dep_model->getDepartment($sdepid); 
                                            if (isset($getdep)) {
                                                echo $getdep->depname;
                                            }
                                            ?>
                                                
                                        </td>
                                        <td><?php echo $idata->reg; ?></td>
                                       
                                        <td>
                                            <?php 
                                            $bookid = $idata->book;
                                            $getbook = $this->book_model->bookById($bookid); 
                                            if (isset($getbook)) {
                                                echo $getbook->bookname;
                                            }
                                            ?>
                                                
                                        </td>
                                        <td><?php echo date("d/m/Y h:ia", strtotime($idata->date)); ?></td>
                                        <td><?php echo $idata->return_book; ?></td>
                                        <td>
                                            <a onclick="return confirm('Are you sure to delete')" href="<?php echo base_url(); ?>manage/dellist/<?php echo $idata->id; ?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a> ||

                                             <a target="_blank" href="<?php echo base_url(); ?>manage/viewstudent/<?php echo $idata->reg; ?>" role="button" data-toggle="modal"><i class="fa fa-eye"></i></a>
                                        </td>
                                    </tr>
                                   
                                    <?php } ?>
                                    
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
