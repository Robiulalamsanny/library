
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Edit Student</h4> 
                              <?php
                                $msg = $this->session->flashdata('msg');
                                if (isset($msg)) {
                                    echo  $msg;
                                }
                           ?>
                          
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-8">
                                  
                                    <!-- <form role="form" class="form-horizontal" action="<?php echo base_url(); ?>student/updateStudent" method="post"> -->

                                     <form action="<?php echo base_url(); ?>student/updateStudent" class=form-horizontal enctype="multipart/form-data" method="post" accept-charset="utf-8">


                                        <input  type="hidden" name="sid" value="<?php echo $stubyid->sid;?>"  >

                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Student Name</label>
                                            </div>
                                            
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="name" value="<?php echo $stubyid->name;?>"  >
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Department</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="dep">
                                                <option>Select One</option>
                                                <?php 
                                                    foreach ($departmentData as $ddata) { ?>
                                                        <?php if ($stubyid->dep == $ddata->depid) { ?>
                                                           <option value="<?php echo $ddata->depid?>" selected="selected">
                                                            <?php echo $ddata->depname?>
                                                               
                                                           </option>  
                                                            <?php   } ?>
                                                <option value="<?php echo $ddata->depid?>">
                                                    <?php echo $ddata->depname?> 
                                                </option>
                                                <?php } ?>
                                            </select>
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Roll No</label>
                                            </div>

                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="roll" value="<?php echo $stubyid->roll;?>" >
                                            </div>
                                        </div>

                                         <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Reg. No</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text" class="form-control" name="reg" value="<?php echo $stubyid->reg;?>" >
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Phone No</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text"  class="form-control" name="phone" value="<?php echo $stubyid->phone;?>">
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div class="col-md-4">
                                            <label>Image</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="file"  class="form-control" name="image" >
                                            <input class="input-file uniform_on" name="stu_old_image" id="fileInput" value="<?php echo $stubyid->image; ?>" type="hidden">
                                            <img src="<?php echo base_url().$stubyid->image; ?>" width="50" height="50" alt="">
                                            </div>
                                        </div>

                                        

                                      <div class="form-group">
                                            <div class="col-md-4"></div>

                                            <div class="col-md-8">
                                             
                                                 <input class="btn btn-primary" type="submit" value="submit" >
                                            </div>
                                        </div>

                                       
                                    </form>
                           
                                </div>
                      
                               <div class="col-lg-4">
                                </div>
                      
                            </div>
                         
                        </div>
                     
                    </div>
                   
                </div>
        
      








