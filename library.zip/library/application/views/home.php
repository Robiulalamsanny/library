<?php if (isset($header)) { echo $header; } ?>
    <div id="wrapper">

        <!-- Navigation -->
<?php if (isset($sidebar)) { echo $sidebar; } ?>
        <div id="page-wrapper">
            <div class="row">
             <?php if (isset($content)) { echo $content; } ?>
     
            </div>
          
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
 <?php if (isset($footer)) { echo $footer; } ?>