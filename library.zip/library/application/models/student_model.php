<?php

class Student_model extends CI_Model{
	
	public function save_student($data){
		$this->db->insert('tbl_student', $data);
	}

	public function getAllStudent($data){
		$this->db->select('*');
		$this->db->from('tbl_student');
		$this->db->order_by('sid', 'desc');
		$qresult = $this->db->get();
		$result = $qresult->result();
		return  $result;
	}

	public function getStudentById($sid){
		$this->db->select('*');
		$this->db->from('tbl_student');
		$this->db->where('sid', $sid);
		$qresult = $this->db->get();
		$result = $qresult->row();
		return  $result;
	}


	// public function updateStudentData($data){
	// 	$this->db->set('name', $data['name']);
	// 	$this->db->set('dep', $data['dep']);
	// 	$this->db->set('roll', $data['roll']);
	// 	$this->db->set('reg', $data['reg']);
	// 	$this->db->set('phone', $data['phone']);
	// 	$this->db->where('sid', $data['sid']);
	// 	$this->db->update('tbl_student');
	// }


	public function updateStudentData($image_upload){
		$data= array();
		$sid = $this->input->post('sid', True);
		$data['name'] = $this->input->post('name', True);
		$data['dep'] = $this->input->post('dep', True);
		$data['roll'] = $this->input->post('roll', True);
		$data['reg'] = $this->input->post('reg', True);
		$data['phone'] = $this->input->post('phone', True);
		$data['image'] = $image_upload;
		$this->db->where('sid', $sid);
		$this->db->update('tbl_student', $data);

	}

	public function delStudentById($sid){
		$this->db->where('sid', $sid);
		$this->db->delete('tbl_student');
	}


}
?>