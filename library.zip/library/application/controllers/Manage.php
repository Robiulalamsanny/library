<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage extends CI_Controller {

	public function __construct(){
		parent::__construct();
		// Cache Control Code
		$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
		$this->output->set_header('Cache-Control: post-check=0, per-check=0', false);
		$this->output->set_header('Pragma: no-cache');
		$this->load->model('manage_model');
		$this->load->model('book_model');
		$this->load->model('student_model');
		$this->load->model('dep_model');
		$data = array();
		if (!$this->session->userdata('userlogin')) {
			redirect('user/login');
		}
	}


	public function issuebook()
	{
		$data['title'] = 'Issue Book';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['getDepartment'] = $this->dep_model->getAllDepartment($data);
		$data['content'] = $this->load->view('inc/issuebook', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}


	public function getBookByDepId($dep)
	{
		$getAllBook = $this->manage_model->getBookByDep($dep);
		$output = null;
		$output .='<option value="0">Select One</option>';
		foreach ($getAllBook as $book) {
			$output .= '<option value="'.$book->bookid.'">'.$book->bookname.'</option>';
		}
		echo $output;
	}


	public function addIssueForm()
	{
		$data['studentname'] = $this->input->post('studentname');
		$data['reg'] = $this->input->post('reg');
		$data['dep'] = $this->input->post('dep');
		$data['book'] = $this->input->post('book');
		$data['return_book'] = $this->input->post('return_book');


		$studentname 	= $data['studentname'];
		$reg 	= $data['reg'];
		$dep	= $data['dep'];
		$book 	= $data['book'];
		$return_book 	= $data['return_book'];
		if (empty($studentname) && empty($reg) && empty($dep) && empty($book) && empty($return_book) ) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("manage/issuebook");
		}else{
			$this->manage_model->saveIssueData($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Data Add Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("manage/issuebook");
		}
	}


	public function issuebooklist(){
		$data['title'] = 'Student List';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['allIssuebook'] = $this->manage_model->getAllIssuebook();
		$data['content'] = $this->load->view('inc/issuebooklist', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}


	public function dellist($id){
		$this->manage_model->delListById($id);
		$sdata = array();
		$sdata['msg'] = '<span style="color:green;">Data Deleted Sucessfully.  </span> ';
		$this->session->set_flashdata($sdata);
		redirect("manage/issuebooklist");

	}


	public function viewstudent($reg){
		$data['title'] = 'View Student';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['studentdata'] = $this->manage_model->getStudentByReg($reg);
		$data['content'] = $this->load->view('inc/viewstudent', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	


}
