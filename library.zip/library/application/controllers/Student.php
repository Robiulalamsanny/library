<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	public function __construct(){
		parent::__construct();
		// Cache Control Code
		$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
		$this->output->set_header('Cache-Control: post-check=0, per-check=0', false);
		$this->output->set_header('Pragma: no-cache');
		$this->load->model('student_model');
		$this->load->model('dep_model');
		$data = array();
		if (!$this->session->userdata('userlogin')) {
			redirect('user/login');
		}
	}

	

	public function addstudent()
	{
		$data['title'] = 'Add Student';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['getDepartment'] = $this->dep_model->getAllDepartment($data);
		$data['content'] = $this->load->view('inc/studentadd', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}



	// image function

	private function image_upload(){
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size'] = 1000;
		$config['max_width'] = 1024;
		$config['max_height'] = 768;

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('image')) {
			$data = $this->upload->data();
			$image_path = "uploads/$data[file_name]";
			return $image_path;
		}else{
			$error = $this->upload->display_errors();
			print_r($error);
		}
	}

	public function addStudentForm()
	{
		$data['name'] = $this->input->post('name');
		$data['dep'] = $this->input->post('dep');
		$data['roll'] = $this->input->post('roll');
		$data['reg'] = $this->input->post('reg');
		$data['phone'] = $this->input->post('phone');
		$data['image'] = $this->image_upload();


		$name 	= $data['name'];
		$dep 	= $data['dep'];
		$roll	= $data['roll'];
		$reg 	= $data['reg'];
		$phone 	= $data['phone'];
		$image  = $data['image'];
		if (empty($name) && empty($dep) && empty($roll) && empty($reg) && empty($phone) && empty($image)) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("student/addstudent");
		}else{
			$this->student_model->save_student($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Data Add Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("student/addstudent");
		}
	}


	public function studentlist(){
		$data['title'] = 'Student List';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);

		$data['getstudent'] = $this->student_model->getAllStudent($data);
		$data['content'] = $this->load->view('inc/liststudent', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}


	public function editstudent($sid){
		$data['title'] = 'Edit Student';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['departmentData'] = $this->dep_model->getAllDepartment();
		$data['stubyid'] = $this->student_model->getStudentById($sid);
		$data['content'] = $this->load->view('inc/studentedit', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	public function updateStudent()
	{
	
		if ($_FILES['image']['name'] == '' || $_FILES['image']['size'] == '0') {

  			$image_upload = $this->input->post('stu_old_image', True);
  			$this->student_model->updateStudentData($image_upload);
  			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Updated Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
  			$sid = $this->input->post('sid', True);
  			redirect("student/studentlist/".$sid);
  		}else
  		{

  			$image_upload = $this->image_upload();
  			$this->student_model->updateStudentData($image_upload);
  			unlink( $this->input->post('stu_old_image', True));
  			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Updated Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
  			$sid = $this->input->post('sid', True);
  			redirect("student/studentlist/".$sid);
  		}
  	


	
	}





	public function delstudent($sid){
		$this->student_model->delStudentById($sid);
		$sdata = array();
		$sdata['msg'] = '<span style="color:green;">Data Deleted Sucessfully.  </span> ';
		$this->session->set_flashdata($sdata);
		redirect("student/studentlist");

	}


}
