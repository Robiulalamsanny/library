<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {

	public function __construct(){
		parent::__construct();
		// Cache Control Code
		$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
		$this->output->set_header('Cache-Control: post-check=0, per-check=0', false);
		$this->output->set_header('Pragma: no-cache');
		$this->load->model('book_model');
		$this->load->model('dep_model');
		$data = array();
		if (!$this->session->userdata('userlogin')) {
			redirect('user/login');
		}
	}

	public function addbook()
	{
		$data['title'] = 'Add New Book';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['getDepartment'] = $this->dep_model->getAllDepartment($data);
		$data['content'] = $this->load->view('inc/addbook', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}


	public function addBookForm()
	{
		$data['bookname'] = $this->input->post('bookname');
		$data['dep'] = $this->input->post('dep');
		$data['author'] = $this->input->post('author');


		$bookname 	= $data['bookname'];
		$dep 	= $data['dep'];
		$author	= $data['author'];
		if (empty($bookname) && empty($dep) && empty($author) ) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("book/addbook");
		}else{
			$this->book_model->save_book($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Data Add Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("book/addbook");
		}
	}

	public function booklist()
	{
		$data['title'] = 'Book List';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['allBook'] = $this->book_model->getAllBookData();
		$data['content'] = $this->load->view('inc/booklist', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	public function editbook($bookid)
	{
		$data['title'] = 'Edit Book ';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['departmentData'] = $this->dep_model->getAllDepartment();
		$data['bookById'] = $this->book_model->bookById($bookid);
		$data['content'] = $this->load->view('inc/editbook', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}



	public function updateBookForm()
	{
		$data['bookid'] = $this->input->post('bookid');
		$data['bookname'] = $this->input->post('bookname');
		$data['dep'] = $this->input->post('dep');
		$data['author'] = $this->input->post('author');


		$bookid 	= $data['bookid'];
		$bookname 	= $data['bookname'];
		$dep 		= $data['dep'];
		$author		= $data['author'];
		if (empty($bookname) && empty($dep) && empty($author) ) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("book/editbook/".$bookid);
		}else{
			$this->book_model->updateBook($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Data Updateed Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("book/editbook/".$bookid);
		}
	}


	public function delbook($bookid){
		$this->book_model->delBookById($bookid);
		$sdata = array();
		$sdata['msg'] = '<span style="color:green;">Data Deleted Sucessfully.  </span> ';
		$this->session->set_flashdata($sdata);
		redirect("book/booklist");

	}



	


}
