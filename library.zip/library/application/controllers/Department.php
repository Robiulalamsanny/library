<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Department extends CI_Controller {

	public function __construct(){
		parent::__construct();
		// Cache Control Code
		$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
		$this->output->set_header('Cache-Control: post-check=0, per-check=0', false);
		$this->output->set_header('Pragma: no-cache');
		$this->load->model('dep_model');
		$data = array();
		if (!$this->session->userdata('userlogin')) {
			redirect('user/login');
		}
	}

	public function adddepartment()
	{
		$data['title'] = 'Add Department';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['content'] = $this->load->view('inc/departmentadd', '', TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	public function addDepartmentForm()
	{
		$data['depname'] = $this->input->post('depname');

		$depname 	= $data['depname'];

		if (empty($depname)  ) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("department/adddepartment");
		}else{
			$this->dep_model->saveDepartment($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Student Data Add Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("department/adddepartment");
		}
	}

	public function departmentlist()
	{
		

		$data['title'] = 'Department List';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['getDepartment'] = $this->dep_model->getAllDepartment($data);
		$data['content'] = $this->load->view('inc/listdepartment', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	public function editdepartment($depid)
	{
		$data['title'] = 'Edit Department';
		$data['header'] = $this->load->view('inc/header', $data, TRUE);
		$data['sidebar'] = $this->load->view('inc/sidebar', '', TRUE);
		$data['depById'] = $this->dep_model->getDepById($depid);
		$data['content'] = $this->load->view('inc/departmentedit', $data, TRUE);
		$data['footer'] = $this->load->view('inc/footer', '', TRUE);
		$this->load->view('home', $data);
	}

	public function updateDepartmentForm()
	{
		$data['depid'] = $this->input->post('depid');
		$data['depname'] = $this->input->post('depname');

		$depid  	= $data['depid'];
		$depname 	= $data['depname'];

		if (empty($depname)  ) {
			$sdata = array();
			$sdata['msg'] = '<span style="color:red;">Field Must Not be empty ! </span> ';
			$this->session->set_flashdata($sdata);
			redirect("department/editdepartment/".$depid);
		}else{
			$this->dep_model->updateDepartmentData($data);
			$sdata = array();
			$sdata['msg'] = '<span style="color:green;">Department Updated Sucessfully.  </span> ';
			$this->session->set_flashdata($sdata);
			redirect("department/editdepartment/".$depid);
		}
	}

	public function deldepartment($depid){
		$this->dep_model->delDepById($depid);
		$sdata = array();
		$sdata['msg'] = '<span style="color:green;">Data Deleted Sucessfully.  </span> ';
		$this->session->set_flashdata($sdata);
		redirect("department/departmentlist");

	}

	


}
